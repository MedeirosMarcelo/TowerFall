# TowerFall 3D
Unity3D Towerfall 3D prototype

- Splitscreen
- Controller
- Flechas limitadas
- Pegar flechas
- Pegar flechas durante o dash
- Flechas especiais
- Morrer
- Colisão da câmera
- Power Up
 - Asas
 - Invisibilidade
 - Escudo
- Pular na cabeca do adversario
- UI
 - flechas
 - Placar
- Scenes
 - Menus


## Dodge Stalling

A regular dodge lasts 20 frames, or 0.333 seconds, with a cooldown period of 25 frames, or 0.416
seconds (altogether 45 frames, 0.75 seconds). Holding a Dodge button will extend a dodge for an
extra 5 frames (for a total of 25 frames, 0.416 seconds), allowing the player to catch arrows that
would otherwise strike them during their dodge cooldown. 

	




