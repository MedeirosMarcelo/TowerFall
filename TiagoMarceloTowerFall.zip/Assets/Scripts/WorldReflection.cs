﻿using UnityEngine;
using System.Collections;

public class WorldReflection : MonoBehaviour {
    public GameObject PlayerReflection;
}
